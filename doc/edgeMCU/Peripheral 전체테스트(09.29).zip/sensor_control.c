#include "sensor_control.h"

int gLCD = 0;
int fd_fnd = 0;
int gCount = 0;

char WriteData[4][9] = { 	
				{WRITE, 0x00, 0x11, 'R', 'A', 'S', 'P', 'I', '\n'},
				{WRITE, 0x00, 0x11, 'B', 'E', 'R', 'R', 'Y', '\n'},
				{WRITE, 0x00, 0x11, 'H', 'E', 'L', 'L', 'O', '\n'},
				{WRITE, 0x00, 0x11, 'W', 'O', 'L', 'R', 'D', '\n'}
			};		
void pinSetup() {

	printf("Setup........\n\n\n");

	if(wiringPiSetup() < 0)	return;	// wiringPi setup
	pinMode(SWITCH_SELECT_PLUS, INPUT);
	pinMode(SWITCH_SELECT_MINUS, INPUT);
	pinMode(PIR, INPUT);
	pinMode(LED_0, OUTPUT);
	pinMode(LED_1, OUTPUT);
	pinMode(CS_ADC, OUTPUT);
	pinMode(CS_EEPROM, OUTPUT);
	pinMode(DC_POSITIVE, OUTPUT);
	pinMode(DC_NEGATIVE, OUTPUT);
	pinMode(DC_ENABLE, OUTPUT);
	pinMode(SERVO, OUTPUT);
	pinMode(ECHO, INPUT);
	pinMode(TRIGGER, OUTPUT);

	digitalWrite(TRIGGER, LOW);

	digitalWrite(CS_EEPROM, HIGH);
	digitalWrite(CS_ADC, HIGH);

	softToneCreate(PIEZO);
	softPwmCreate(SERVO, 0, 200);

	gLCD = lcdInit(2, 16, 4, 27, 25, 1,2,3,4,0,0,0,0);

	fd_fnd = wiringPiI2CSetup(FND_I2C_ADDR);
	if(wiringPiSPISetup(SPI_CHANNEL, SPI_SPEED) < 0) return;



	wiringPiI2CWriteReg16(fd_fnd, CONFIG_PORT0, 0x0000);



	digitalWrite(LED_0, HIGH);
	digitalWrite(LED_1, HIGH);
	delay(500);
	digitalWrite(LED_0, LOW);
	digitalWrite(LED_1, LOW);
	delay(500);
	digitalWrite(LED_0, HIGH);
	digitalWrite(LED_1, HIGH);
	delay(500);
	digitalWrite(LED_0, LOW);
	digitalWrite(LED_1, LOW);
	delay(500);


	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, 0xFF00);
	delay(500);
	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, 0x0000);	
	delay(500);
	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, 0xFF00);
	delay(500);
	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, 0x0000);	
	delay(500);





}

void turnOff() {
	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, 0x0000);
	digitalWrite(LED_0, LOW);
	digitalWrite(LED_1, LOW);
	lcdClear(gLCD);
	digitalWrite(DC_ENABLE, LOW);
	digitalWrite(SERVO, LOW);
}

void pirTest() {

	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "PIR O-LED9 ON ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "PIR X-LED8 Off");


	if(!digitalRead(PIR)) {
		digitalWrite(LED_0, HIGH);
		digitalWrite(LED_1, LOW);
	}

	else {
		digitalWrite(LED_0, LOW);
		digitalWrite(LED_1, HIGH);
	}

}

void vrTest() {

	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "VR -> ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "PIEZO");

	int adcValue_VR = 0;

	while(1) {
		if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) break;
		adcValue_VR = analogToDigital(1);
		softToneWrite(PIEZO, adcValue_VR);
		delay(100);		
		softToneWrite(PIEZO, 0);
	}

}

void motorTest_Stop() {
	int i;
	for(i=0; i<5; i++) {
		if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) {
			digitalWrite(DC_ENABLE, LOW);
			break;
		}	
		delay(100);
	}
}

void motorTest() {

	int fd_Led8_Step = wiringPiI2CSetup(STEP_I2C_ADDR);
	wiringPiI2CWriteReg16(fd_Led8_Step, CONFIG_PORT0, 0x0000);	
	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT0, 0x0000);	

	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "DC -> STEP ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "-> SERVO");


	int aRotate[4] = {0x10, 0x20, 0x40, 0x80};
	int i;

//	while(1) {

		digitalWrite(DC_POSITIVE, HIGH);
		digitalWrite(DC_NEGATIVE, LOW);
		digitalWrite(DC_ENABLE, HIGH);

		motorTest_Stop();

		digitalWrite(DC_ENABLE, LOW);

		motorTest_Stop();

		digitalWrite(DC_POSITIVE, LOW);
		digitalWrite(DC_NEGATIVE, HIGH);
		digitalWrite(DC_ENABLE, HIGH);

		motorTest_Stop();

		digitalWrite(DC_ENABLE, LOW);

		motorTest_Stop();
	

		int count = 0;

		while(count < 50) {
			for(i=0; i<4; i++) {
				wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT0, aRotate[i]);
				delay(10);
			}
			count++;
			if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) {
				digitalWrite(DC_ENABLE, LOW);
				return;
			}
		}

		softPwmWrite(SERVO, 1);

		motorTest_Stop();

		softPwmWrite(SERVO, 15);

		motorTest_Stop();

		softPwmWrite(SERVO, 23);

		motorTest_Stop();

		softPwmWrite(SERVO, 15);

		motorTest_Stop();	
//	}
}



void cdsLightTempHumiSoundTest() {

	int cdsValue = 0;
	int soundValue = 0;
	float lightValue = 0.0;
	float temp = 0.0;
	float humi = 0.0;

	
	int data[3];
	int i;
	int tmp;


	int fd_Light = wiringPiI2CSetup(LIGHT_I2C_ADDR);
	wiringPiI2CWrite(fd_Light, LIGHT_I2C_RESET);

	int fd_temphumi = wiringPiI2CSetup(SHT20_I2C_ADDR);

	wiringPiI2CWrite(fd_temphumi, SHT20_SOFT_RESET);
	delay(50);


	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "CDS,LIGHT,SOUND ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "TEMP/HUMI");



//	while(1) {

//		if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) break;

		cdsValue = analogToDigital(0);
		soundValue = analogToDigital(2);

		wiringPiI2CWrite(fd_Light, LIGHT_I2C_CON_HR_MODE);

		delay(260);
		for(i = 0; i < 2; i++)
			data[i] = wiringPiI2CRead(fd_Light);

		tmp = (data[0]*265) + data[1];
		lightValue = (int)tmp / 1.2;



		
		wiringPiI2CWrite(fd_temphumi, SHT20_I2C_CMD_MEASURE_TEMP);
		delay(260);

		for(i=0; i<2; i++)
			data[i] = wiringPiI2CRead(fd_temphumi);

		tmp = data[0] << 8 | data[1];
		temp = -46.85 + 175.72/65536*(int)tmp;


                wiringPiI2CWrite(fd_temphumi, SHT20_I2C_CMD_MEASURE_HUMI);
                delay(260);

                for(i=0; i<2; i++)
                        data[i] = wiringPiI2CRead(fd_temphumi);

                tmp = data[0] << 8 | data[1];
                humi = -6.0 + 125.0/65536*(int)tmp;


		printf("LIGHT : %.1f\n", (float)lightValue);
		printf("CDS : %d\n", cdsValue);
		printf("SOUND : %d\n", soundValue);

		printf("TEMP : %.1f\n", (float)temp);
		printf("HUMI : %.1f\n\n", (float)humi);

		delay(500);

//	}


}


void saveReadEeprom_stop(int count){
	int i;
	for(i=0; i<count; i++) {
		if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) {
			return;
		}	
		delay(100);
	}

}
void saveReadEeprom() {


	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "EEPROM ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "SAVE & READ");


	char buff[9];
	int i;

	// Set
	digitalWrite(CS_EEPROM, LOW);
	delayMicroseconds(1);
	buff[0] = WREN;
	wiringPiSPIDataRW(SPI_CHANNEL, buff, 1);
	delayMicroseconds(1);
	digitalWrite(CS_EEPROM, HIGH);
	delay(1);

	printf("Save DATA On the EEPROM\n");
	printf("wait a minutes\n");
	// write
	digitalWrite(CS_EEPROM, LOW);
	delayMicroseconds(1);

	for(i=0; i<9; i++) {
		buff[i] = WriteData[gCount][i];
	}
	gCount++;
	if(gCount > 3) gCount = 0;
/*
	buff[0] = WRITE;
	buff[1] = 0x00;		// address [15:8]
	buff[2] = 0x11;		// address [7:0]
	buff[3] = 'R';
	buff[4] = 'A';
	buff[5] = 'S';
	buff[6] = 'P';
	buff[7] = 'I';
	buff[8] = '\n';
*/
	wiringPiSPIDataRW(SPI_CHANNEL, buff, 9);
	delayMicroseconds(1000);
	digitalWrite(CS_EEPROM, HIGH);
	saveReadEeprom_stop(20);

	// reset
	digitalWrite(CS_EEPROM, LOW);
	delayMicroseconds(1);
	buff[0] = WRDI;
	wiringPiSPIDataRW(SPI_CHANNEL, buff, 1);
	delayMicroseconds(1);
	digitalWrite(CS_EEPROM, HIGH);
	delay(1);
	printf("Read DATA On the EEPROM\n");
	printf("wait a minutes\n");

	// Read
	digitalWrite(CS_EEPROM, LOW);
	delayMicroseconds(1);
	buff[0] = READ;
	buff[1] = 0x00;
	buff[2] = 0x11;
	wiringPiSPIDataRW(SPI_CHANNEL, buff, 9);
	delayMicroseconds(1000);
	digitalWrite(CS_EEPROM, HIGH);
	saveReadEeprom_stop(10);


	printf("\n\n");
	printf("READ : ");
	for(i = 3; i < 9; i++) {
		printf("%c", buff[i]);
	}
	printf("\n\n");
	saveReadEeprom_stop(10);


}


void fndDisplay() {


	lcdClear(gLCD);
	lcdPosition(gLCD, 0, 0);
	lcdPuts(gLCD, "ULTRASONIC ");

	lcdPosition(gLCD, 0, 1);
	lcdPuts(gLCD, "-> FND ");


	wiringPiI2CWriteReg16(fd_fnd, CONFIG_PORT0, 0x0000);
	while(1)
	{
		if(digitalRead(SWITCH_SELECT_MINUS) || digitalRead(SWITCH_SELECT_PLUS)) {
			return;
		}		
		digitalWrite(TRIGGER, HIGH);
		delayMicroseconds(15);
		digitalWrite(TRIGGER, LOW);

		while(digitalRead(ECHO) == LOW);
		long startTime = micros();

		while(digitalRead(ECHO) == HIGH);
		long travelTime = micros() - startTime;

		int distance = travelTime / 58;

		i2cSendValue(distance);
	}


}

int analogToDigital(char adcChannel) {

	char buff[3];

	int adcValue = 0;

	buff[0] = 0x06 | ((adcChannel & 0x07) >> 2);
	buff[1] = ((adcChannel & 0x07) << 6);
	buff[2] = 0x00;

	digitalWrite(CS_ADC,LOW);
	wiringPiSPIDataRW(SPI_CHANNEL, buff, 3);

	buff[1] = 0x0F & buff[1];
	adcValue = (buff[1] << 8) | buff[2];

	digitalWrite(CS_ADC, HIGH);

	return adcValue;
}

void i2cSendValue(int tempCycles)
{
	unsigned long temp = 0;
	unsigned char FND_data[10] = {0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0x3E, 0xE0, 0xFE, 0xF6};

	temp = tempCycles / 100000;
        temp = FND_data[temp] << 8;
        temp = temp + 0x007F;
        wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
        tempCycles %= 100000;
        delay(2);

	temp = tempCycles / 10000;
	temp = FND_data[temp] << 8;
	temp = temp + 0x00BF;
	wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
	tempCycles %= 10000;
	delay(2);


        temp = tempCycles / 1000;
        temp = FND_data[temp] << 8;
        temp = temp + 0x00DF;
        wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
        tempCycles %= 1000;
        delay(2);

        temp = tempCycles / 100;
        temp = FND_data[temp] << 8;
        temp = temp + 0x00EF;
        wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
        tempCycles %= 100;
        delay(2);

        temp = tempCycles / 10;
        temp = FND_data[temp] << 8;
        temp = temp + 0x00F7;
        wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
        tempCycles %= 10;
        delay(2);

        temp = tempCycles;
        temp = FND_data[temp] << 8;
        temp = temp + 0x00FB;
        wiringPiI2CWriteReg16(fd_fnd, OUT_PORT0, temp);
        delay(2);
}

void printMenu() {

	printf("\n\n");
	printf("//////////////////////////////////////////////////////////////////\n");
	printf("led0 - LED by the PIR \n");
	printf("led1 - PIEZO by the VR \n");
	printf("led2 - DC -> STEP -> SERVO \n");
	printf("led3 - CDS / LIGHT, TEMP/HUMI, SOUND \n");
	printf("led4 - The Data save on the EEPROM & read the data on the EEPROM\n");
	printf("led5 - FND display by the ULTRASONIC \n");
	printf("led6 - IR Remote Control \n");
	printf("led7 - GESTURE \n");
	printf("//////////////////////////////////////////////////////////////////\n");


	printf("SW1 - NEXT MENU\n");
	printf("SW0 - PREV MENU\n");
	printf("//////////////////////////////////////////////////////////////////\n\n");

}
