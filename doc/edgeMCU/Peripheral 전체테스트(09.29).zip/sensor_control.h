#ifndef PERIPHERAL_H
#define PERIPHERAL_H

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <softTone.h>
#include <softPwm.h>


#include <wiringPi.h>
#include <wiringPiI2C.h>
#include <lcd.h>

#define STEP_I2C_ADDR		0x20
#define LED_I2C_ADDR		0x20
#define FND_I2C_ADDR		0x21
#define IN_PORT0		0x00
#define IN_PORT1		0x01
#define OUT_PORT0		0x02
#define OUT_PORT1		0x03
#define POLARITY_IVE_PORT0	0x04
#define POLARITY_IVE_PORT1	0x05
#define CONFIG_PORT0		0x06
#define CONFIG_PORT1		0x07

#define SPI_CHANNEL		0
#define SPI_SPEED		1000000


#define SPI_CHANNEL	0
#define SPI_SPEED	1000000

#define WREN		0x06
#define WRDI		0x04
#define RDSR		0x05
#define WRSR		0x01
#define READ		0x03
#define WRITE		0x02



// PIN NUMBER
#define SWITCH_SELECT_PLUS 		22
#define SWITCH_SELECT_MINUS		21
#define PIR 				5
#define LED_0  				29
#define LED_1  				28
#define PIEZO 				23
#define DC_ENABLE			26
#define DC_POSITIVE			7
#define DC_NEGATIVE			6
#define SERVO 				0
#define ECHO				31
#define TRIGGER				30
#define CS_ADC				11
#define CS_EEPROM			10


#define LIGHT_I2C_ADDR			0x23
#define LIGHT_I2C_POWER_DOWN		0x00
#define LIGHT_I2C_POWER_ON		0x01
#define LIGHT_I2C_RESET			0x07
#define LIGHT_I2C_CON_HR_MODE		0x10

#define SHT20_I2C_ADDR			0x40
#define SHT20_I2C_CMD_MEASURE_TEMP	0xF3
#define SHT20_I2C_CMD_MEASURE_HUMI	0xF5
#define SHT20_SOFT_RESET		0xFE

void startMenu(int);

void pirTest();						
void vrTest();
void motorTest();
void motorTest_Stop();
void cdsLightTempHumiSoundTest();

int analogToDigital(char);

void fndDisplay();
void saveReadEeprom();
void saveReadEeprom_stop(int);
void pinSetup();
void turnOff();
void printMenu();
void i2cSendValue(int);
#endif