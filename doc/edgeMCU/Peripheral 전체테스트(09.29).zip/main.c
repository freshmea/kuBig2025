#include "sensor_control.h"

void sig_handler(int);		// ctrl + c process stop

void ISR_selectMenu1_8();		// menu select
void ISR_selectMenu8_1();		// stop & start

int gSelectMenuNumber = 0;	// menu number
int gStartStopFlag = 1;		// stop & start variable

const int aLedData[8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};	// 8LED On

int gLcd = 0;
int fd_Led8_Step = 0;

int main() {

	signal(SIGINT, (void *)sig_handler);	// interrupt

	fd_Led8_Step = wiringPiI2CSetup(LED_I2C_ADDR);
	gLcd = lcdInit(2, 16, 4, 27, 25, 1,2,3,4,0,0,0,0);

	pinSetup();		// setup pin


	wiringPiISR(SWITCH_SELECT_MINUS, INT_EDGE_FALLING, &ISR_selectMenu8_1);
	wiringPiISR(SWITCH_SELECT_PLUS, INT_EDGE_FALLING, &ISR_selectMenu1_8);

	wiringPiI2CWriteReg16(fd_Led8_Step, CONFIG_PORT1, 0x0000);	
	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, 0x0000);	

	delay(1000);

	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, 0x00FF);
	delay(500);
	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, 0x0000);
	delay(500);

	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, 0x00FF);
	delay(500);
	wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, 0x0000);
	delay(500);	


	printf("edge-Embedded Peripheral Test Program Start\n\n\n");
	delay(2000);


	printMenu();


	lcdClear(gLcd);

	lcdPosition(gLcd, 0, 0);
	lcdPuts(gLcd, "@@Test Program@@");

	lcdPosition(gLcd, 0, 1);
	lcdPuts(gLcd, "@@@@@START@@@@@@");

	delay(4000);

	while(1) {

		if(gStartStopFlag) {
			
			wiringPiI2CWriteReg16(fd_Led8_Step, OUT_PORT1, aLedData[gSelectMenuNumber]);

			startMenu(gSelectMenuNumber);
		}
		else {
			lcdClear(gLcd);
			lcdPosition(gLcd, 0, 0);
			lcdPuts(gLcd, "STATE");
			lcdPosition(gLcd, 0, 1);
			lcdPuts(gLcd, "STOP");
		}
		delay(100);
	}

	return 0;
}

// ***************interrupt function********************
void ISR_selectMenu1_8() {
	gSelectMenuNumber++;
	if(gSelectMenuNumber > 7) 	gSelectMenuNumber = 0;
	
	printMenu();

}

void ISR_selectMenu8_1() {
	gSelectMenuNumber--;
	if(gSelectMenuNumber < 0)	gSelectMenuNumber = 7;
				
	printMenu();
}

void sig_handler(int signo) {
	wiringPiI2CWriteReg16(wiringPiI2CSetup(LED_I2C_ADDR), OUT_PORT1, 0x0000);	
	turnOff();
	exit(0);
}

// *******************************************************

void startMenu(int menuNumber) {

	turnOff();

	switch(menuNumber) {
		case 0:

			pirTest();
			break;
		case 1:

			vrTest();
			break;
		case 2:

			motorTest();
			break;
		case 3:

			cdsLightTempHumiSoundTest();
			break;
		case 4:

			saveReadEeprom();
			break;
		case 5:
			fndDisplay();
			break;
		case 6:
			lcdClear(gLcd);
			lcdPosition(gLcd, 0, 0);
			lcdPuts(gLcd, "####IR Test#####");
			lcdPosition(gLcd, 0, 1);
			lcdPuts(gLcd, "################");

			printf("/////////////////////////////////////////////////////\n");
			printf("////             IR Remote Control 0~9           ////\n");
			printf("////               If you want to stop,          ////\n");
			printf("////   Please Push SW0 or SW1 and Press Ctrl+C   ////\n");
			printf("/////////////////////////////////////////////////////\n");
			system("irw");
			break;
		case 7:
			lcdClear(gLcd);
			lcdPosition(gLcd, 0, 0);
			lcdPuts(gLcd, "##Gesture Test##");
			lcdPosition(gLcd, 0, 1);
			lcdPuts(gLcd, "################");

			printf("/////////////////////////////////////////////////////\n");
			printf("////                  Start Gesture              ////\n");
			printf("////               If you want to stop,          ////\n");
			printf("////   Please Push SW0 or SW1 and Press Ctrl+C   ////\n");
			printf("/////////////////////////////////////////////////////\n");
			system("./gesture");
			break;
	}
}
