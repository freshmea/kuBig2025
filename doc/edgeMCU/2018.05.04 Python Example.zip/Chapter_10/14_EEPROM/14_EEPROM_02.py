#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time
import spidev

CS_EEPROM = 8
SPI_CHANNEL = 0
SPI_SPEED = 1000000

WREN = 0x06
WRDI = 0x04
RDSR = 0x05
WRSR = 0x01
READ = 0x03
WRITE = 0x02
 
buff = [0,0,0,0,0,0,0,0,0]

string = ""

GPIO.setmode(GPIO.BCM)

spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 100000

try:
    spi.writebytes([WREN]) 

    time.sleep(0.001)

    message = input ("save : ")
    
    buff[0] = WRITE     
    buff[1] = 0x00      
    buff[2] = 0x11
    for i in range(5):
        buff[i+3] = ord(message[i]) 
    buff[8] = ord('\n')

    spi.xfer(buff)   
    time.sleep(5)
    
    spi.writebytes([WRDI])
    time.sleep(0.001)

    buff[0] = READ  
    buff[1] = 0x00     
    buff[2] = 0x11
        
    for i in range(3, 9):
        buff[i] = 0x00
     
    data = spi.xfer2(buff) 
    time.sleep(1)

    del(data[0:3])

    for i in range(6): 
        string = string+chr(data[i])

    print ("READ : ") 
    print (string)
    
except KeyboardInterrupt: 
    spi.close() 