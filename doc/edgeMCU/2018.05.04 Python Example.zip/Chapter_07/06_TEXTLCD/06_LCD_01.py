#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time
import lcd

try:
    lcd.setup()     
    while True:
        lcd.lcd_string("EdgeiLAB", lcd.lcdLine1)    
        lcd.lcd_string("Hello World", lcd.lcdLine2) 
        time.sleep(3)
        
        lcd.lcd_string("1234567890123457", lcd.lcdLine1)
        lcd.lcd_string("abcdefghijklmnop", lcd.lcdLine2)
        time.sleep(3)

except KeyboardInterrupt:
    GPIO.cleanup()   
