#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

lcdRs = 16
lcdE = 26
lcdD0 = 18
lcdD1 = 27
lcdD2 = 22
lcdD3 = 23

lcdWidth = 16
lcdChr = True
lcdCmd = False
 
lcdLine1 = 0x80
lcdLine2 = 0xC0

def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(lcdE, GPIO.OUT) 
    GPIO.setup(lcdRs, GPIO.OUT)
    GPIO.setup(lcdD0, GPIO.OUT)
    GPIO.setup(lcdD1, GPIO.OUT)
    GPIO.setup(lcdD2, GPIO.OUT)
    GPIO.setup(lcdD3, GPIO.OUT)

    lcd_init()

def lcd_init():
    lcd_byte(0x33, lcdCmd) 
    lcd_byte(0x32, lcdCmd)  
    lcd_byte(0x06, lcdCmd) 
    lcd_byte(0x0C, lcdCmd) 
    lcd_byte(0x28, lcdCmd)  
    lcd_byte(0x01, lcdCmd)   
    time.sleep(0.0005)

def lcd_byte(bits, mode):
    GPIO.output(lcdRs, mode)

    GPIO.output(lcdD0, False)
    GPIO.output(lcdD1, False)
    GPIO.output(lcdD2, False)
    GPIO.output(lcdD3, False)
    if bits&0x10 == 0x10:
        GPIO.output(lcdD0, True)
    if bits&0x20 == 0x20:
        GPIO.output(lcdD1, True)
    if bits&0x40 == 0x40:
        GPIO.output(lcdD2, True)
    if bits&0x80 == 0x80:
        GPIO.output(lcdD3, True)

    lcd_toggle_enable()

    GPIO.output(lcdD0, False)
    GPIO.output(lcdD1, False)
    GPIO.output(lcdD2, False)
    GPIO.output(lcdD3, False)
    if bits&0x01 == 0x01:
        GPIO.output(lcdD0, True)
    if bits&0x02 == 0x02:
        GPIO.output(lcdD1, True)
    if bits&0x04 == 0x04:
        GPIO.output(lcdD2, True)
    if bits&0x08 == 0x08:
        GPIO.output(lcdD3, True)

    lcd_toggle_enable()

def lcd_toggle_enable():
    time.sleep(0.0005)
    GPIO.output(lcdE, True) 
    time.sleep(0.0005)
    GPIO.output(lcdE, False)
    time.sleep(0.0005)

def lcd_string(message, line):
    message = message.ljust(lcdWidth, " ")

    lcd_byte(line, lcdCmd)  

    for i in range(lcdWidth):
        lcd_byte(ord(message[i]), lcdChr)
