#-*-coding: utf-8-*-

import smbus
import time

step_addr = 0x20

IN_PORT0 = 0x00
IN_PORT1 = 0x01
OUT_PORT0 = 0x02
OUT_PORT1 = 0x03
POLARITY_PORT0 = 0x04
POLARITY_PORT1 = 0x05
CONFIG_PORT0 = 0x06
CONFIG_PORT1 = 0x07

lPhase_1 = [0x80, 0x40, 0x20, 0x10]

bus = smbus.SMBus(1)

bus.write_byte_data(step_addr, CONFIG_PORT0, 0x00)

try:
    while True: 
        for i in range(4): 
            bus.write_byte_data(step_addr, OUT_PORT0, lPhase_1[i])
            time.sleep(0.01)

except KeyboardInterrupt: 
    pass 