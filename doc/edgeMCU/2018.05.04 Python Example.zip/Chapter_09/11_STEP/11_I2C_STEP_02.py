#-*-coding: utf-8-*-

import stepMotor
import time
import RPi.GPIO as GPIO

pinSwitch = [5, 6]

GPIO.setmode(GPIO.BCM)

for i in range(2):
    GPIO.setup(pinSwitch[i], GPIO.IN)

interruptFlag = 0
 
def changePhaseTo2(chnnel):
    global interruptFlag
    interruptFlag = 2

def changePhaseTo12(chnnel):
    global interruptFlag
    interruptFlag = 12
   
stepMotor.init()

GPIO.add_event_detect(pinSwitch[0], GPIO.RISING, callback=changePhaseTo2)
GPIO.add_event_detect(pinSwitch[1], GPIO.RISING, callback=changePhaseTo12)


try:
    while True: 
        if interruptFlag == 2:
            stepMotor.phase2(False) 
        elif interruptFlag == 12: 
            stepMotor.phase12(True) 

except KeyboardInterrupt: 
    GPIO.cleanup()    
