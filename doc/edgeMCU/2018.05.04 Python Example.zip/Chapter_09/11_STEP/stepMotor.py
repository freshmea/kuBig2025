#-*-coding: utf-8-*-

import smbus
import time

step_addr = 0x20

IN_PORT0 = 0x00
IN_PORT1 = 0x01
OUT_PORT0 = 0x02
OUT_PORT1 = 0x03
POLARITY_PORT0 = 0x04
POLARITY_PORT1 = 0x05
CONFIG_PORT0 = 0x06
CONFIG_PORT1 = 0x07

bus = smbus.SMBus(1)

def init():
    bus = smbus.SMBus(1)

    bus.write_byte_data(step_addr, CONFIG_PORT0, 0x00)

def phase1(direction):
    data = [0x80, 0x40, 0x20, 0x10] 
    if direction == True:  
        for i in range(4):   
            bus.write_byte_data(step_addr, OUT_PORT0, data[i])
            time.sleep(0.01)

    elif direction == False: 
        for i in range(3, 0, -1): 
            bus.write_byte_data(step_addr, OUT_PORT0, data[i])
            time.sleep(0.01)

def phase2(direction):
    data = [0xC0, 0x60, 0x30, 0x90] 
    if direction == False: 
        for i in range(4): 
           bus.write_byte_data(step_addr, OUT_PORT0, data[i])
           time.sleep(0.01)
 
    elif direction == True: 
        for i in range(3, 0, -1): 
            bus.write_byte_data(step_addr, OUT_PORT0, data[i])
            time.sleep(0.01)

def phase12(direction):
    data = [0x10, 0x30, 0x20, 0x60, 0x40, 0xC0, 0x80, 0x90] 
    if direction == True: 
        for i in range(8): 
            bus.write_byte_data(step_addr, OUT_PORT0, data[i])
            time.sleep(0.01)

    elif direction == False:  
        for i in range(7, 0, -1):
            bus.write_byte_data(step_addr, OUT_PORT0, data[i])
            time.sleep(0.01)

