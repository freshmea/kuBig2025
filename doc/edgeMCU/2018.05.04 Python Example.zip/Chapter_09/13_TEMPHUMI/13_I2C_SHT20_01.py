#-*-coding: utf-8-*-

import smbus
import time

sht20_addr = 0x40

SHT20_CMD_MEASURE_TEMP = 0xF3
SHT20_CMD_MEASURE_HUMI = 0xF5
SHT20_SOFT_RESET = 0xFE

bus = smbus.SMBus(1)

bus.write_byte(sht20_addr, SHT20_SOFT_RESET)
time.sleep(0.05)

lData = [0, 0]

try:
    while True:
        bus.write_byte(sht20_addr, SHT20_CMD_MEASURE_TEMP)
        time.sleep(0.26)
        for i in range(2):
            lData[i] = bus.read_byte(sht20_addr)
        value = lData[0] << 8 | lData[1]
        temp = -46.84 + 175.72/65536*int(value)

        bus.write_byte(sht20_addr, SHT20_CMD_MEASURE_HUMI)
        time.sleep(0.26)
        for i in range(2):
            lData[i] = bus.read_byte(sht20_addr)
        value = lData[0] << 8 | lData[1]
        humi = -6.0 + 125.0/65536*int(value)

        print("temp : %.1f  'C\n" %float(temp))
        print("Humi : %.1f  %%\n" %float(humi))

        time.sleep(1)

except KeyboardInterrupt:  
    pass   