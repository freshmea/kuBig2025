#-*-coding: utf-8-*-

class Temperature:
    temp = 0.0
    humi = 0.0

    def getTemp(self):
        return self.temp
    def setTemp(self, value):
        self.temp = value
    def getHumi(self):
        return self.humi 
    def setHumi(self, value):
        self.humi = value

import smbus
import time
import lcd
import RPi.GPIO as GPIO

motorEnable = 12
motorPositive = 4
motorNegative = 25
 
sht20_addr = 0x40

SHT20_CMD_MEASURE_TEMP = 0xF3
SHT20_CMD_MEASURE_HUMI = 0xF5
SHT20_SOFT_RESET = 0xFE

GPIO.setmode(GPIO.BCM)

GPIO.setup(motorEnable, GPIO.OUT)
GPIO.setup(motorPositive, GPIO.OUT)
GPIO.setup(motorNegative, GPIO.OUT)

bus = smbus.SMBus(1)

myTemp = Temperature()

bus.write_byte(sht20_addr, SHT20_SOFT_RESET)
time.sleep(0.05)

lData = [0, 0]

try:
    lcd.setup()
    while True:
        bus.write_byte(sht20_addr, SHT20_CMD_MEASURE_TEMP)
        time.sleep(0.26)
        for i in range(2):
            lData[i] = bus.read_byte(sht20_addr)
        value = lData[0] << 8 | lData[1]
        temp = -46.84 + 175.72/65536*int(value)

        myTemp.setTemp(temp)
        lcd.lcd_string("temp : %.1f[C]" %float(temp), lcd.lcdLine1)

        bus.write_byte(sht20_addr, SHT20_CMD_MEASURE_HUMI)
        time.sleep(0.26)
        for i in range(2):
            lData[i] = bus.read_byte(sht20_addr)
        value = lData[0] << 8 | lData[1]
        humi = -6.0 + 125.0/65536*int(value)

        myTemp.setHumi(humi)
        lcd.lcd_string("Humi : %.1f[%%]" %float(humi), lcd.lcdLine2)        

        if myTemp.getTemp() >= 30 or myTemp.getHumi() >= 60:
            GPIO.output(motorEnable, True)
            GPIO.output(motorPositive, True)
            GPIO.output(motorNegative, False)
        else:
            GPIO.output(motorEnable, False)

        time.sleep(1)

except KeyboardInterrupt:  
    GPIO.cleanup()  