#-*-coding: utf-8-*-

import time
import smbus

light_addr = 0x23

LIGHT_POWER_DOWN = 0x00
LIGHT_POWER_ON = 0x01
LIGHT_RESET = 0x07
LIGHT_CON_HR_MODE = 0x10

bus = smbus.SMBus(1)

bus.write_byte(light_addr, LIGHT_RESET)
time.sleep(0.05)

lightValue = 0.0
lData = [0, 0]
value = 0

try:
    while True:
        bus.write_byte(light_addr, LIGHT_CON_HR_MODE)
        time.sleep(0.26)
        
        for i in range(2):
            lData[i] = bus.read_byte(light_addr)

        value = lData[0] * 256
        value = value + lData[1]
        
        lightValue = value/ 1.2

        print("LIGHT : %.1f \n" % lightValue)
        time.sleep(1)
        

except KeyboardInterrupt:   
    pass    