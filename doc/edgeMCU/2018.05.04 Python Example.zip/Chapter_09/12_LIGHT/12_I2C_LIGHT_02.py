#-*-coding: utf-8-*-

class SmartLamp:
    switch = False
    light = 0

    def getLight(self):
        return self.light
    def setLight(self, value):
        self.light = value

    def getSwitch(self):
        return self.switch
    def setSwitch(self, switch):
        self.switch = switch
        
import RPi.GPIO as GPIO
import time
import smbus

pinLed = 21

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinLed, GPIO.OUT)

light_addr = 0x23

LIGHT_POWER_DOWN = 0x00
LIGHT_POWER_ON = 0x01
LIGHT_RESET = 0x07
LIGHT_CON_HR_MODE = 0x10

bus = smbus.SMBus(1)

smartLamp = SmartLamp()

bus.write_byte(light_addr, LIGHT_RESET)
time.sleep(0.05)

lData = [0, 0]
value = 0

try:
    while True:
        bus.write_byte(light_addr, LIGHT_CON_HR_MODE)
        time.sleep(0.26)

        for i in range(2):
            lData[i] = bus.read_byte(light_addr)

        value = (lData[0] * 256) /1.2
        smartLamp.setLight(value)

        if smartLamp.getLight() <= 500:
            smartLamp.setSwitch(True)
        else:
            smartLamp.setSwitch(False)

        if smartLamp.getSwitch() == True:
            GPIO.output(pinLed, True)
        else:
            GPIO.output(pinLed, False)

except KeyboardInterrupt:   
    GPIO.cleanup()   
