#-*-coding: utf-8-*-

import smbus
import time

led_addr = 0x20

bus = smbus.SMBus(1)

IN_PORT1 = 0x01
OUT_PORT1 = 0x03
POLARITY_IVE_PORT1 = 0x05
CONFIG_PORT1 = 0x07

lLedData = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80]

bus.write_byte_data(led_addr, CONFIG_PORT1, 0x00)


try:
    while True:         
        for i in range(8): 
            bus.write_byte_data(led_addr, OUT_PORT1, lLedData[i])
            time.sleep(0.5)
except KeyboardInterrupt:   
    pass   
