#-*-coding:utf-8-*-

import RPi.GPIO as GPIO
import time
import smbus

led_addr = 0x20     

IN_PORT1 = 0x01
OUT_PORT1 = 0x03
POLARITY_IVE_PORT1 = 0x05
CONFIG_PORT1 = 0x07

bus = smbus.SMBus(1)

pinSwitch = [6, 5] 

lLedData = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80]

interruptFlag = False

def switchFlagToTrue(chnnel):
    global interruptFlag
    interruptFlag = True

def switchFlagToFalse(chnnel):
    global interruptFlag 
    interruptFlag = False

bus.write_byte_data(led_addr, CONFIG_PORT1, 0x00)

GPIO.setmode(GPIO.BCM)

for i in range(2):
    GPIO.setup(pinSwitch[i], GPIO.IN)
 
GPIO.add_event_detect(pinSwitch[0], GPIO.RISING, callback=switchFlagToFalse)
GPIO.add_event_detect(pinSwitch[1], GPIO.RISING, callback=switchFlagToTrue)

try:
    while True:   
        if interruptFlag == False:     
            for i in range(8):    
                bus.write_byte_data(led_addr, OUT_PORT1,lLedData[i])
                time.sleep(0.2)
        else:
            for i in range(7, 0, -1):    
                bus.write_byte_data(led_addr, OUT_PORT1, lLedData[i])
                time.sleep(0.2)

except KeyboardInterrupt: 
    GPIO.cleanup()   
         
        
