#-*-coding: utf-8-*-

import smbus
import time

fnd_addr = 0x21

IN_PORT0 = 0x00
IN_PORT1 = 0x01
OUT_PORT0 = 0x02
OUT_PORT1 = 0x03
POLARITY_PORT0 = 0x04
POLARITY_PORT1 = 0x05
CONFIG_PORT0 = 0x06
CONFIG_PORT1 = 0x07

lFndData = [0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0x3E, 0xE0, 0xFE, 0xF6]

lFndSelect = [0x7E, 0xBF, 0xDF, 0xEF, 0xF7, 0xFB]

bus = smbus.SMBus(1)

bus.write_word_data(fnd_addr, CONFIG_PORT0, 0x0000)

def fibonacci(n):
    if n == 0 or n == 1: 
        return 1    
    else: 
        return fibonacci(n-1) + fibonacci(n-2)

def displayNumber(number):
    lPosition = [0, 0, 0, 0, 0, 0] 
    lPosition[0] = number/100000
    lPosition[1] = number%100000/10000
    lPosition[2] = number%10000/1000
    lPosition[3] = number%1000/100
    lPosition[4] = number%100/10
    lPosition[5] = number%10

    for i in range(6): 
        temp = lFndData[lPosition[i]] << 8 | lFndSelect[i] 
        bus.write_word_data(fnd_addr, OUT_PORT0, temp) 
        time.sleep(0.001)
    
count = 0

try:
    while True:
        result = fibonacci(count)  
        if result >= 99999:  
            count = 0           
            
        for i in range(20):     
            displayNumber(result)
            
        count += 1  

except KeyboardInterrupt:   
    pass   