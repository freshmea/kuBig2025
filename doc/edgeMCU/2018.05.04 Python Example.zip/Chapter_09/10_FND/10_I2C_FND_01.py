#-*-coding: utf-8-*-

import smbus
import time

fnd_addr = 0x21

IN_PORT0 = 0x00
IN_PORT1 = 0x01
OUT_PORT0 = 0x02
OUT_PORT1 = 0x03
POLARITY_PORT0 = 0x04
POLARITY_PORT1 = 0x05
CONFIG_PORT0 = 0x06
CONFIG_PORT1 = 0x07

lFndData = [0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0x3E, 0xE0, 0xFE, 0xF6]

lFndSelect = [0x7E, 0xBF, 0xDF, 0xEF, 0xF7, 0xFB]

bus = smbus.SMBus(1)

bus.write_byte_data(fnd_addr, CONFIG_PORT0, 0x00)

count = 0 

try:
    while True:
        temp = ((lFndData[count]<<8) | lFndSelect[5])
        bus.write_word_data(fnd_addr, OUT_PORT0, temp) 
        count += 1 
        time.sleep(1)

        if count > 9: 
            count = 0

except KeyboardInterrupt:  
    pass   