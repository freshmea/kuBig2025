#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import spidev
import time

pinPiezo = 13
GPIO.setmode(GPIO.BCM)
GPIO.setup(pinPiezo, GPIO.OUT)
Buzz = GPIO.PWM(pinPiezo, 440)

spi = spidev.SpiDev()
spi.open(0, 1)
spi.max_speed_hz = 100000

time.sleep(0.0005)

def readAdc(channel):
    r = spi.xfer2([1, (8 + channel) << 4, 0])
    adc_out = ((r[1] & 3) << 8) + r[2]
    return adc_out

try:
    while True:
        Buzz.start(50) 
        val = readAdc(1)
        Buzz.ChangeFrequency(val+1)
        time.sleep(0.01)

except KeyboardInterrupt:
    GPIO.cleanup()
    spi.close()    