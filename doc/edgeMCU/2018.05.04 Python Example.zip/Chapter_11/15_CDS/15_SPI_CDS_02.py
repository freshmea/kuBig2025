#-*-coding: utf-8-*-

import spidev
import smbus
import time

led_addr = 0x20
bus = smbus.SMBus(1)
IN_PORT1 = 0x01
OUT_PORT1 = 0x03
POLARITY_IVE_PORT1 = 0x05
CONFIG_PORT1 = 0x07
lLedData = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80]
bus.write_byte_data(led_addr, CONFIG_PORT1, 0x00)

spi = spidev.SpiDev()
spi.open(0, 1)
spi.max_speed_hz = 100000
time.sleep(0.0005)

def readAdc(channel):
    r = spi.xfer2([1, (8 + channel) << 4, 0])
    adc_out = ((r[1] & 3) << 8) + r[2]
    return adc_out

def ledOnByRange(x, minimum, maximum, ledNo):
    if(x > minimum and x <= maximum):
        data = 0x00
        for i in range(ledNo):
            data = lLedData[i] | data
        bus.write_byte_data(led_addr, OUT_PORT1, data)
        time.sleep(0.2)
        
try:
    while True:
        val = readAdc(0)
        voltage = val * 3.3 /1024
        print ("ADC result : %d \t voltage = %.2f" %(val, voltage))
        
        ledOnByRange(val, 0, 300, 8)
        ledOnByRange(val, 300, 600, 4)
        ledOnByRange(val, 600, 1023, 1)

        time.sleep(1)

except KeyboardInterrupt:  
    spi.close()   
    
