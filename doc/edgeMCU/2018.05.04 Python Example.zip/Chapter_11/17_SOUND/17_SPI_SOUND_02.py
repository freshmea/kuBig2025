#-*-coding: utf-8-*-

import spidev
import time

spi = spidev.SpiDev()
spi.open(0, 1)
spi.max_speed_hz = 100000

fileForWrite = None
fileForWrite = open("/home/pi/Desktop/Python Example/Chapter_11/17_SOUND/sound_data.txt", 'w')

time.sleep(0.0005)

def readAdc(channel):
    r = spi.xfer2([1, (8 + channel) << 4, 0])
    adc_out = ((r[1] & 3) << 8) + r[2]
    return adc_out

def writeStr(string):
    global fileForWrite
    if string != "":
        fileForWrite.writelines(string+'\n')
    
try:
    while True:
        val = readAdc(2)
        voltage = val * 3.3 /1024
        print ("ADC result : %d \t voltage = %.2f" %(val, voltage))
         writeStr(str(val))
        time.sleep(1)

except KeyboardInterrupt: 
    fileForWrite.close()
    spi.close()  