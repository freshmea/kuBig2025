#-*-coding: utf-8-*-

import time

fileForRead = None 
StrToRead = []      
inStr = ''

fileForRead = open("/home/pi/Desktop/Python Example/Chapter_11/17_SOUND/sound_data.txt", 'r')  

StrToRead = fileForRead.readlines() 

for inStr in StrToRead :   
    print (inStr + "")

fileForRead.close()
