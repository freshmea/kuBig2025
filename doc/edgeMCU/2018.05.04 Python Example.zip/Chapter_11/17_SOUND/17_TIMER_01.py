#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time
import smbus
import threading

pinPiezo = 13
pinLed = 21
pinSwitch = 6

alarmFlag = False

fnd_addr = 0x21

IN_PORT0 = 0x00
IN_PORT1 = 0x01
OUT_PORT0 = 0x02
OUT_PORT1 = 0x03
POLARITY_PORT0 = 0x04
POLARITY_PORT1 = 0x05
CONFIG_PORT0 = 0x06
CONFIG_PORT1 = 0x07

lFndData = [0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0x3E, 0xE0, 0xFE, 0xF6]

lFndSelect = [0x7E, 0xBF, 0xDF, 0xEF, 0xF7, 0xFB]

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinPiezo, GPIO.OUT)
GPIO.setup(pinLed, GPIO.OUT)
GPIO.setup(pinSwitch, GPIO.IN)

Buzz = GPIO.PWM(pinPiezo, 440)

bus = smbus.SMBus(1)

bus.write_word_data(fnd_addr, CONFIG_PORT0, 0x0000)

def displayNumber(number):
    lPosition = [0, 0, 0, 0, 0, 0] 
    lPosition[0] = int(number/100000)
    lPosition[1] = int(number%100000/10000)
    lPosition[2] = int(number%10000/1000)
    lPosition[3] = int(number%1000/100)
    lPosition[4] = int(number%100/10)
    lPosition[5] = int(number%10)

    for i in range(6):
        temp = (lFndData[lPosition[i]] << 8 | lFndSelect[i])
        bus.write_word_data(fnd_addr, OUT_PORT0, temp) 
        time.sleep(0.001)

def buzzerOn():
    global alarmFlag
    Buzz.start(50)
    for i in range(0, len(lMelody)):
        Buzz.ChangeFrequency(lMelody[i])
        time.sleep(0.3)
    Buzz.stop()
    GPIO.output(pinLed, False)
    alarmFlag = False

def timerOn(sec):
    t = threading.Timer(sec, buzzerOn)
    t.start()

def alarmOn(channel):
    global alarmFlag
    if alarmFlag == False: 
        GPIO.output(pinLed, True) 
        timerOn(10.0) 
        alarmFlag = True

GPIO.add_event_detect(pinSwitch, GPIO.RISING, callback = alarmOn)
    
try:
    while True:
        t = time.localtime()
        hour = str(t[3]).rjust(2, '0')
        minute = str(t[4]).rjust(2, '0')
        second = str(t[5]).rjust(2, '0')
        
        strTime = hour + minute + second
        intTime = int(strTime)
        displayNumber(intTime)

except KeyboardInterrupt:  
    GPIO.cleanup()  