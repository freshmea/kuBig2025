#-*-coding: utf-8-*-

import time
import smbus
import picamera

servo_addr = 0x20

OUT_PORT0 = 0x02
CONFIG_PORT0 = 0x06

period = 0.02

servoUD = 0x01
servoLR = 0x02

bus = smbus.SMBus(1)

bus.write_byte_data(servo_addr,CONFIG_PORT0, 0x00)

camera = picamera.PiCamera()
camera.start_preview()

try:
    while True: 
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoUD) #HIGH 상태로 설정 
            time.sleep(0.00005)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00) #LOW 상태로 설정 
            time.sleep(period - 0.00005)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoUD)
            time.sleep(0.0006)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.0006)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoUD)
            time.sleep(0.0015)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.0015)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoUD)
            time.sleep(0.0006)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.0006)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoLR)
            time.sleep(0.00005)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.00005)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoLR)
            time.sleep(0.001)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.001)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoLR)
            time.sleep(0.002)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.002)
        for i in range(50):
            bus.write_byte_data(servo_addr, OUT_PORT0, servoLR)
            time.sleep(0.001)
            bus.write_byte_data(servo_addr, OUT_PORT0, 0x00)
            time.sleep(period - 0.001)           
        camera.capture("image4.jpg")
        
except KeyboardInterrupt:
    camera.stop_preview() 