#-*-coding: utf-8-*-

import lirc 
import RPi.GPIO as GPIO
import time

led = 21

sockid = lirc.init("myprogram")

GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT)

try:
    while True: 
        codeIR = lirc.nextcode() 
        print (codeIR)
        if codeIR != []:
            if codeIR[0] == "one": 
                GPIO.output(led, True) 
            elif codeIR[0] == "two": 
                GPIO.output(led, False) 
except KeyboardInterrupt: 
    lirc.deinit() 
    GPIO.cleanup() 


    
