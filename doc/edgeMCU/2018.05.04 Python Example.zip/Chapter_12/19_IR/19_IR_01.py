#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinIr = 19

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinIr, GPIO.IN)

try:
    while True: 
        if GPIO.input(pinIr) == False:
            print ("Read")
        time.sleep(0.1)

except KeyboardInterrupt:
    GPIO.cleanup() 