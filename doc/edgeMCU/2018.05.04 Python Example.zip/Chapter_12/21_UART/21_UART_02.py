#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time
import spidev
import serial

CS_EEPROM = 8
SPI_CHANNEL = 0
SPI_SPEED = 1000000

WREN = 0x06
WRDI = 0x04
RDSR = 0x05
WRSR = 0x01
READ = 0x03
WRITE = 0x02

buff = [0,0,0,0,0,0,0,0,0]

string = ""
 
GPIO.setmode(GPIO.BCM)

mySerial = serial.Serial('/dev/serial0',baudrate=115200,timeout=3.0)

if mySerial.isOpen() == False:
    mySerial.open()

mySerial.flushInput()
mySerial.flushOutput()

spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 100000

mySerial.write("testing \n")

response = ""

try:
    spi.writebytes([WREN]) 

    time.sleep(0.001)

    mySerial.write("input string")

    while True:
        if mySerial.inWaiting() != 0: 
            response = response+mySerial.read(1)
        if len(response) >= 5: 
            break
        
    buff[0] = WRITE  
    buff[1] = 0x00  
    buff[2] = 0x11
    buff[3] = ord(response[0]) 
    buff[4] = ord(response[1])
    buff[5] = ord(response[2])
    buff[6] = ord(response[3])
    buff[7] = ord(response[4])
    buff[8] = ord('\n')

    print map(chr, buff)

    spi.xfer(buff) 
    '''    
    for i in range(0, 9):
        spi.writebytes([buff[i]])
        time.sleep(0.001)
    '''
    time.sleep(5)
    
    spi.writebytes([WRDI]) 
    time.sleep(0.001)

    buff[0] = READ 
    buff[1] = 0x00 
    buff[2] = 0x11
    
    for i in range(3, 9): 
        buff[i] = 0x00

    data = spi.xfer2(buff) 
    time.sleep(1)

    del(data[0:3]) 

    for i in range(6): 
        string = string+chr(data[i])

    print "READ : " 
    print string
    
except KeyboardInterrupt: 
    spi.close() 