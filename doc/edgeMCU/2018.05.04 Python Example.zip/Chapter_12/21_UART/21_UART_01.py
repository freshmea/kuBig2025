#-*-coding: utf-8-*-

import serial

mySerial = serial.Serial('/dev/serial0',baudrate=115200,timeout=3.0)

if mySerial.isOpen() == False:
    mySerial.open()

mySerial.flushInput()
mySerial.flushOutput()

mySerial.write(b'Hello World')

try:
    while True: 
        if mySerial.inWaiting() != 0: 
            response = mySerial.read() 
            print(response.decode('utf-8')) 
            
except KeyboardInterrupt: 
    mySerial.close()
