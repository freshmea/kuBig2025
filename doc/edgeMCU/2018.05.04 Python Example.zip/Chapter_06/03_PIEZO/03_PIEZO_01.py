#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinPiezo = 13

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinPiezo, GPIO.OUT)

Buzz = GPIO.PWM(pinPiezo, 440)

try:
    while True:
        Buzz.start(50) 
        for i in range(0, len(lMelody)): 
            Buzz.ChangeFrequency(lMelody[i]) 
            time.sleep(0.3)  
        Buzz.stop()    
        time.sleep(1) 

except KeyboardInterrupt: 
    GPIO.cleanup()   
