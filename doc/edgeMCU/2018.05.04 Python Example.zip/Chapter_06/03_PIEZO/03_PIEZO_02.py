#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinPiezo = 13
lpinLed = [21, 20]
lpinSwitch = [6, 5]

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinPiezo, GPIO.OUT)

for i in range(2):
    GPIO.setup(lpinLed[i], GPIO.OUT)
    GPIO.setup(lpinSwitch[i], GPIO.IN)

Buzz = GPIO.PWM(pinPiezo, 440)

interruptFlag = False

def turnOnTheSiren(channel):
    global interruptFlag 
    interruptFlag = True

def turnOffTheSiren(channel):
    global interruptFlag
    interruptFlag = False
    
GPIO.add_event_detect(lpinSwitch[0], GPIO.RISING, callback=turnOnTheSiren)
GPIO.add_event_detect(lpinSwitch[1], GPIO.RISING, callback=turnOffTheSiren)

try:
    while True: 
        if interruptFlag == True:            
            Buzz.start(50) 
            GPIO.output(lpinLed[0], True)
            GPIO.output(lpinLed[1], False)
            Buzz.ChangeFrequency(lMelody[2])
            time.sleep(0.3) 
            GPIO.output(lpinLed[0], False)
            GPIO.output(lpinLed[1], True)
            Buzz.ChangeFrequency(lMelody[0])
            time.sleep(0.3)
        else:
            Buzz.stop()   
            for i in range(2):
                GPIO.output(lpinLed[i], False)

except KeyboardInterrupt: 
    GPIO.cleanup()  
