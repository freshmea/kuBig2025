#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinPir = 24

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinPir, GPIO.IN)

try:
    while True:    
        if GPIO.input(pinPir) == False: 
            print ("Detected")    
            time.sleep(0.5)  

except KeyboardInterrupt:   
    GPIO.cleanup()          
            
            
