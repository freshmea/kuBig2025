#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinPir = 24
lpinLed = [21, 20]
pinPiezo = 13

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinPiezo, GPIO.OUT)

GPIO.setup(pinPir, GPIO.IN)

for i in range(2):
    GPIO.setup(lpinLed[i], GPIO.OUT)

Buzz = GPIO.PWM(pinPiezo, 440)

try:
    while True:    
        if GPIO.input(pinPir) == False:  
            Buzz.start(50) 
            Buzz.ChangeFrequency(lMelody[6])
            GPIO.output(lpinLed[0], False)            
            GPIO.output(lpinLed[1], True)
        else:
            GPIO.output(lpinLed[0], True)
            GPIO.output(lpinLed[1], False)
            
        time.sleep(0.5)    
        Buzz.stop()

except KeyboardInterrupt:  
    GPIO.cleanup()           
            
            
