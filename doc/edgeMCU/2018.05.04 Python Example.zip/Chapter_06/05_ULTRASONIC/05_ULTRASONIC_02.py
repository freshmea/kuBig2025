#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

def measure():
    GPIO.output(pinTrigger, True) 
    time.sleep(0.00001)
    GPIO.output(pinTrigger, False)
    start = time.time() 

    while GPIO.input(pinEcho) == False:
        start = time.time() 

    while GPIO.input(pinEcho) == True:
        stop = time.time()  

    elapsed = stop-start 
    distance = (elapsed * 19000)/2 

    return distance 

def beep():
    Buzz.start(50)
    Buzz.ChangeFrequency(lMelody[2])
    time.sleep(0.2)
    Buzz.stop()

pinTrigger = 0
pinEcho = 1
pinPiezo = 13
pinLed = 21

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinTrigger, GPIO.OUT)
GPIO.setup(pinEcho, GPIO.IN)

GPIO.setup(pinLed, GPIO.OUT)
GPIO.setup(pinPiezo, GPIO.OUT)

Buzz = GPIO.PWM(pinPiezo, 440) 

try:
    while True:
        distance = measure()  
        print ("Distance : %.2f cm" %distance)
        
        if (distance < 15 and distance > 10) :
            beep()
            time.sleep(0.5)
        elif (distance < 10 and distance > 5):
            beep()
            time.sleep(0.1)
        elif (distance < 5):
            Buzz.start(50)
            Buzz.ChangeFrequency(lMelody[2])
            GPIO.output(pinLed, True)
        else :
            Buzz.stop()
            GPIO.output(pinLed, False)
            
except KeyboardInterrupt: 
    GPIO.cleanup() 
