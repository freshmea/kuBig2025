#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

def measure():
    GPIO.output(pinTrigger, True) 
    time.sleep(0.00001)
    GPIO.output(pinTrigger, False)
    start = time.time() 
    
    while GPIO.input(pinEcho) == False: 
        start = time.time() 
        
    while GPIO.input(pinEcho) == True: 
        stop = time.time() 

    elapsed = stop-start 
    distance = (elapsed * 19000)/2 

    return distance 

pinTrigger = 0
pinEcho = 1

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinTrigger, GPIO.OUT)
GPIO.setup(pinEcho, GPIO.IN)

try:
    while True: 
        distance = measure()  
        print ("Distance : %.2f cm" %distance) 
        time.sleep(1) 

except KeyboardInterrupt: 
    GPIO.cleanup()

