#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinLed1 = 21
pinLed2 = 20

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinLed1, GPIO.OUT)
GPIO.setup(pinLed2, GPIO.OUT)

print ("Start LED")

try:
        while True:
                GPIO.output(pinLed1, True)
                GPIO.output(pinLed2, False)
                time.sleep(1)
                GPIO.output(pinLed1, False)
                GPIO.output(pinLed2, True)
                time.sleep(1)

        print ("End LED")
except KeyboardInterrupt:
        GPIO.cleanup()
