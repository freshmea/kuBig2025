#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinSwitch1 = 6
pinSwitch2 = 5

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinSwitch1, GPIO.IN)
GPIO.setup(pinSwitch2, GPIO.IN)

try:
        while True:     
                if GPIO.input(pinSwitch1) == True: 
                        print ("SWITCH 1 Pushed")    
                        time.sleep(0.5)                  
                elif GPIO.input(pinSwitch2) == True:    
                        print ("SWITCH 2 Pushed")           
                        time.sleep(0.5)                         

except KeyboardInterrupt:      
	GPIO.cleanup()      
