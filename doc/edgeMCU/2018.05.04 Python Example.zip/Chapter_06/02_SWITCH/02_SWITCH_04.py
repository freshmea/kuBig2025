#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

led = 21
switch = 6

ledFlag = False

GPIO.setmode(GPIO.BCM)

GPIO.setup(led, GPIO.OUT)  
GPIO.setup(switch, GPIO.IN)

def ledBlink(channel):
    global ledFlag 
    if ledFlag == False:  
        GPIO.output(led, True)
        ledFlag = True   
    else:                    
        GPIO.output(led, False) 
        ledFlag = False 

GPIO.add_event_detect(switch, GPIO.RISING, callback=ledBlink)

try:
        while True: 
            pass 

except KeyboardInterrupt:   
    GPIO.cleanup()             
    
            
