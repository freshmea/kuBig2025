#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

led = 21
switch = 6

GPIO.setmode(GPIO.BCM)

GPIO.setup(led, GPIO.OUT)
GPIO.setup(switch, GPIO.IN)

try:
        while True: 
                if GPIO.input(switch) == True:  
                        GPIO.output(led, True)     
	else:                                     
                        GPIO.output(led, False)   

except KeyboardInterrupt:       
        GPIO.cleanup()             
