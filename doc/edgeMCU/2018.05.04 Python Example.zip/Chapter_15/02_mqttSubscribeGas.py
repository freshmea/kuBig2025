#!/usr/bin/env python
# _*_ coding: utf-8 _*_
import paho.mqtt.client as mqtt
import sys
import time
import libedge.thingplug as thingplug 
import libedge.temperature as temperature
import libedge.dcmotor as dcmotor

addr		= "mqtt.sktiot.com"
id		= "sjs1210"
pw		= "WEZsQytadnBaOGNWandsMzEvK0ZYVlpMbm5QVXNsYmhGb0ZvU20vbVVGTFlCUEVZNGdFZDdhaHRoTDNTeHpYWA=="
deviceId	= "sjs1210_IoT_EM"
targetDeviceId	= "sjs1210_MCU_Node_Gas"
devicePw 	= "123456"
containerTemp	= "temperature"
containerHumi	= "humidity"
containerGas    = "gas"

def callbackFunctionGas(data):
	gas = float(data)
	print("callbackFunction: gas={0}\n".format(gas))
	if gas>26: dcmotor.rotateDcMotor(0, 1) # turn right for 1 sec.

client = mqtt.Client(deviceId, clean_session=True, transport = "tcp")
client.username_pw_set(id, pw)
dcmotor.useDcMotor()

if not thingplug.mqttConnect(client, addr, deviceId):
	print("1. mqtt connect failed\n")
	sys.exit()

if not thingplug.mqttCreateNode(client, deviceId, devicePw):
	print("2. mqtt create node failed\n")
	sys.exit()

if not thingplug.mqttCreateRemoteCSE(client):
	printf("3. mqtt create remote cse failed\n")
	sys.exit()

if not thingplug.mqttCreateContainer(client, deviceId, containerTemp):
	printf("4. mqtt create containerTemp failed\n")
	sys.exit()

if not thingplug.mqttCreateContainer(client, deviceId, containerHumi):
	printf("4. mqtt create containerHumi failed\n")
	sys.exit()
	
if not thingplug.mqttCreateMgmtCmd(client, deviceId):
	printf("5. mqtt create mgmt cmd failed\n")
	sys.exit()

if not thingplug.mqttSubscribe(client, targetDeviceId, containerGas, pw, callbackFunctionGas):
	print("6. mqtt subscribe notification failed\n")
	sys.exit()

if not thingplug.mqttDeleteSubscribe(client, targetDeviceId, pw, containerGas):
	print("7. mqtt Delete subscribe notification failed\n")
	sys.exit()
	
# wait for the subscription.
try:
    for i in range(0, 3):
        temp = temperature.getTempData()
        strTemp = str(temp)
        thingplug.mqttCreateContentInstance(client, deviceId, containerTemp, strTemp)
        time.sleep(1)
    
        humi = temperature.getHumiData()
        strHumi = str(humi)
        thingplug.mqttCreateContentInstance(client, deviceId, containerHumi, strHumi)
        time.sleep(1)
    while(1):
        client.loop_start()
except KeyboardInterrupt:
    client.loop_stop()
    thingplug.mqttDisconnect(client)
    dcmotor.unuseDcMotor()
