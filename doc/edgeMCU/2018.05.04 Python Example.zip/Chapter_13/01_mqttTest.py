import paho.mqtt.client as mqtt
import sys
import time

address		= "iot.eclipse.org"
clientId	         = "ExampleClientPub"
topic		= "MQTT Examples"
payload		= "Hello World!"
qos		= 1

def onConnect(client, usedata, flags, rc):
	if rc!=0:
		print("Failed to connect, return code ", rc)
		sys.exit()

def onPublish(client, userdata, result):
	print("data published\n")
	pass

#client = mqtt.Client(clientId, clean_session=True, transport="tcp")
client = mqtt.Client(clientId)
client.on_connect = onConnect
client.on_publish = onPublish
#client.connect(address, port=1883, keepalive=60)
client.connect(address)
client.loop_start()
print("In wait loop")
time.sleep(1)
print("in Main Loop")
client.loop_stop()

ret = client.publish(topic, payload, qos, False)
if ret[0]==0:
	print("publish success, return code={0}".format(ret))
else: 
	print("publish failed, return code={0}".format(ret))

client.disconnect()
