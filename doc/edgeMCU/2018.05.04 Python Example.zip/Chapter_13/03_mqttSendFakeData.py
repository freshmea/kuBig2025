#!/usr/bin/env python
# _*_ coding: utf-8 _*_
import paho.mqtt.client as mqtt
import sys
import time
import libedge.thingplug as thingplug 
import libedge.temperature as temperature

addr		= "mqtt.sktiot.com"
id		= "sjs1210"
pw		= "WEZsQytadnBaOGNWandsMzEvK0ZYVlpMbm5QVXNsYmhGb0ZvU20vbVVGTFlCUEVZNGdFZDdhaHRoTDNTeHpYWA=="
deviceId	= "sjs1210_iot_em_python"
devicePw 	= "123456"
containerTemp	= "temperature" 

client = mqtt.Client(deviceId, clean_session=True, transport = "tcp")
client.username_pw_set(id, pw)

if not thingplug.mqttConnect(client, addr, deviceId):
	print("1. mqtt connect failed\n")
	sys.exit()

if not thingplug.mqttCreateNode(client, deviceId, devicePw):
	print("2. mqtt create node failed\n")
	sys.exit()
	
if not thingplug.mqttCreateRemoteCSE(client):
	printf("3. mqtt create remote cse failed\n")
	sys.exit()

if not thingplug.mqttCreateContainer(client, deviceId, containerTemp):
	printf("4. mqtt create containerTemp failed\n")
	sys.exit()

if not thingplug.mqttCreateMgmtCmd(client, deviceId):
	printf("5. mqtt create mgmt cmd failed\n")
	sys.exit()   

if not thingplug.mqttCreateContentInstance(client, deviceId, containerTemp, "30"):
	printf("6. mqtt create content instance failed\n")
	sys.exit()    
	
print("Send Fake Data Success")

thingplug.mqttDisconnect(client)


