#!/usr/bin/env python
# _*_ coding: utf-8 _*_
import paho.mqtt.client as mqtt
import sys
import time
import libedge.thingplug as thingplug 
import libedge.temperature as temperature

addr		= "mqtt.sktiot.com"
id		= "sjs1210"
pw		= "WEZsQytadnBaOGNWandsMzEvK0ZYVlpMbm5QVXNsYmhGb0ZvU20vbVVGTFlCUEVZNGdFZDdhaHRoTDNTeHpYWA=="
deviceId	= "sjs1210_iot_em_python"
devicePw 	= "123456"

client = mqtt.Client(deviceId, clean_session=True, transport = "tcp")
client.username_pw_set(id, pw)

if not thingplug.mqttConnect(client, addr, deviceId):
	print("1. mqtt connect failed\n")
	sys.exit()

if not thingplug.mqttCreateNode(client, deviceId, devicePw):
	print("2. mqtt create node failed\n")
	sys.exit()
	
if not thingplug.mqttCreateRemoteCSE(client):
	printf("3. mqtt create remote cse failed\n")
	sys.exit()

print("Create Remote CSE Success")

thingplug.mqttDisconnect(client)


