#!/usr/bin/env python
# _*_ coding: utf-8 _*_
import paho.mqtt.client as mqtt
import sys
import time
import libedge.thingplug as thingplug 
import libedge.temperature as temperature
import libedge.dcmotor as dcmotor

addr		= "mqtt.sktiot.com"
id		= "sjs1210"
pw		= "WEZsQytadnBaOGNWandsMzEvK0ZYVlpMbm5QVXNsYmhGb0ZvU20vbVVGTFlCUEVZNGdFZDdhaHRoTDNTeHpYWA=="
deviceId	= "sjs1210_iot_em_python"
devicePw 	= "123456"
containerTemp	= "temperature"

def callbackFunction(data):
	temp = float(data)
	print("callbackFunction: temp={0}\n".format(temp))
	if temp>60: dcmotor.rotateDcMotor(0, 1) # turn right for 1 sec.	

client = mqtt.Client(deviceId, clean_session=True, transport = "tcp")
client.username_pw_set(id, pw)
dcmotor.useDcMotor()

if not thingplug.mqttConnect(client, addr, deviceId):
	print("1. mqtt connect failed\n")
	sys.exit()

if not thingplug.mqttCreateNode(client, deviceId, devicePw):
	print("2. mqtt create node failed\n")
	sys.exit()

if not thingplug.mqttCreateRemoteCSE(client):
	printf("3. mqtt create remote cse failed\n")
	sys.exit()

if not thingplug.mqttCreateContainer(client, deviceId, containerTemp):
	printf("4. mqtt create container failed\n")
	sys.exit()

if not thingplug.mqttCreateMgmtCmd(client, deviceId):
	printf("5. mqtt create mgmt cmd failed\n")
	sys.exit()


if not thingplug.mqttSubscribe(client, deviceId, container, pw, callbackFunction):
	printf("6. mqtt subscribe notification failed\n")
	sys.exit()

for i in range(0, 30):
	temp = temperature.getHumiData()
	strTemp = str(temp)
	thingplug.mqttCreateContentInstance(client, deviceId, containerTemp, strTemp)
	time.sleep(1)

thingplug.mqttDisconnect(client)
dcmotor.unuseDcMotor()


