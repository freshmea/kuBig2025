#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time
import lcd

pinServo = 17
pinPiezo = 13
lpinLed = [21, 20]
lpinSwitch = [6, 5]

lMelody = [131, 147, 165, 175, 196, 220, 247, 262]

lPassword = [0,0,0,0,0,0]
linput = [0,0,0,0,0,1]

count = 0

def beep():
    Buzz.start(50)
    Buzz.ChangeFrequency(lMelody[2])
    time.sleep(0.2)
    Buzz.stop()

def pushButton0(channel): 
    global count
    linput[count] = 0 
    count += 1
    beep()
    lcd.lcd_byte(lcd.lcdLine2, lcd.lcdCmd) 
    for i in range(count):
        lcd.lcd_byte(ord('*'), lcd.lcdChr)
def pushButton1(channel):
    global count
    linput[count] = 1 
    count += 1
    beep()
    lcd.lcd_byte(lcd.lcdLine2, lcd.lcdCmd)
    for i in range(count):
        lcd.lcd_byte(ord('*'), lcd.lcdChr)
    
GPIO.setmode(GPIO.BCM)

GPIO.setup(pinServo, GPIO.OUT)
GPIO.setup(pinPiezo, GPIO.OUT)
for i in range(2):
    GPIO.setup(lpinLed[i], GPIO.OUT)
    GPIO.setup(lpinSwitch[i], GPIO.IN)
    
servo = GPIO.PWM(pinServo, 50)
Buzz = GPIO.PWM(pinPiezo, 440)

servo.start(2.5)

GPIO.add_event_detect(lpinSwitch[0], GPIO.RISING, callback=pushButton0)
GPIO.add_event_detect(lpinSwitch[1], GPIO.RISING, callback=pushButton1)

try:
    lcd.setup() 
    lcd.lcd_string("press the button", lcd.lcdLine1)
    while True:
        if(count == 6):
            result = 0
            for i in range(6): 
                if(lPassword[i] == linput[i]):
                    result += 1
            if(result == 6): 
                lcd.lcd_string("unlock!!", lcd.lcdLine1)
                servo.ChangeDutyCycle(11.5) 
                for i in range(2):
                    GPIO.output(lpinLed[i], True)
            else: 
                lcd.lcd_string("lock!!", lcd.lcdLine1)
                servo.ChangeDutyCycle(2.5) 
                for i in range(2):
                    GPIO.output(lpinLed[i], False)
            count = 0
            lcd.lcd_string(" ", lcd.lcdLine2)
        
except KeyboardInterrupt: 
    GPIO.cleanup()   
