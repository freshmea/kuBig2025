#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinServo = 17

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinServo, GPIO.OUT)

servo = GPIO.PWM(pinServo, 50)

servo.start(7.5)

try:
    while True: 
        servo.ChangeDutyCycle(2.3) 
        time.sleep(2)
        servo.ChangeDutyCycle(7)
        time.sleep(2)
        servo.ChangeDutyCycle(12) 
        time.sleep(2)

except KeyboardInterrupt: 
    GPIO.cleanup()  
