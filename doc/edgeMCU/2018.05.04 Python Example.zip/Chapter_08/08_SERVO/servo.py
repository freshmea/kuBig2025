import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)

val = 1
inc = 0.1

try:
    while True:
        GPIO.output(17, False)
        time.sleep(val / 1000.0)
        GPIO.output(17, True)
        time.sleep((20-val)/1000.0)
        val += inc
        time.sleep(0.05)

        if val>2 or val <0.6:
            inc *= -1
except KeyboardInterrupt:
    GPIO.cleanup()
        
