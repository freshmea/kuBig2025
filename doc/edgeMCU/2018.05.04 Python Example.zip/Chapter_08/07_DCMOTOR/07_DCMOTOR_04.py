#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinEnable = 12
pinPositive = 4
pinNegative = 25
pinSwitch01 = 6
pinSwitch02 = 5

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinEnable, GPIO.OUT)
GPIO.setup(pinPositive, GPIO.OUT)
GPIO.setup(pinNegative, GPIO.OUT)

GPIO.setup(pinSwitch01, GPIO.IN)
GPIO.setup(pinSwitch02, GPIO.IN)

dcE = GPIO.PWM(pinEnable, 50)

dcE.start(0)

try:
    while True:  
        if GPIO.input(pinSwitch01) == True:
            for i in range(0,30,5):  
                dcE.ChangeDutyCycle(i)
                GPIO.output(pinPositive, True) 
                GPIO.output(pinNegative, False)
                time.sleep(1) 
                print i

        elif GPIO.input(pinSwitch02) == True: 
            GPIO.output(pinEnable, False) 
            GPIO.output(pinPositive, False)
            GPIO.output(pinNegative, False)
            
except KeyboardInterrupt: 
    GPIO.cleanup() 