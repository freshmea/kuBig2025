#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinEnable = 12
pinPositive = 4
pinNegative = 25
pinSwitch01 = 6
pinSwitch02 = 5

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinEnable, GPIO.OUT)
GPIO.setup(pinPositive, GPIO.OUT)
GPIO.setup(pinNegative, GPIO.OUT)

GPIO.setup(pinSwitch01, GPIO.IN)
GPIO.setup(pinSwitch02, GPIO.IN)

def motorSpin(channel):
    GPIO.output(pinEnable, True)     
    GPIO.output(pinPositive, True)
    GPIO.output(pinNegative, False)

def motorStop(channel):
    GPIO.output(pinEnable, False) 

GPIO.add_event_detect(pinSwitch01, GPIO.RISING, callback=motorSpin)
GPIO.add_event_detect(pinSwitch02, GPIO.FALLING, callback=motorStop)

try:
    while True: 
        pass
            
except KeyboardInterrupt:
    GPIO.cleanup()
