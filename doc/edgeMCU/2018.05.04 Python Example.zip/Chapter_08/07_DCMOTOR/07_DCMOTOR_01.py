#-*-coding:utf-8-*-

import RPi.GPIO as GPIO
import time

pinEnable = 12
pinPositive = 4
pinNegative = 25

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinEnable, GPIO.OUT)
GPIO.setup(pinPositive, GPIO.OUT)
GPIO.setup(pinNegative, GPIO.OUT)

try:
    while True: 
        GPIO.output(pinEnable, True) 
        GPIO.output(pinPositive, True)
        GPIO.output(pinNegative, False)
        time.sleep(1)

        GPIO.output(pinEnable, False) 
        time.sleep(1)

        GPIO.output(pinEnable, True) 
        GPIO.output(pinPositive, False)
        GPIO.output(pinNegative, True) 
        time.sleep(1) 

        GPIO.output(pinEnable, False) 
        time.sleep(1) 

except KeyboardInterrupt: 
    GPIO.cleanup() 
        
