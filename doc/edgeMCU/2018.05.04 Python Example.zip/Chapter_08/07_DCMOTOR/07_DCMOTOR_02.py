#-*-coding: utf-8-*-

import RPi.GPIO as GPIO
import time

pinEnable = 12
pinPositive = 4
pinNegative = 25
pinSwitch01 = 6
pinSwitch02 = 5

GPIO.setmode(GPIO.BCM)

GPIO.setup(pinEnable, GPIO.OUT)
GPIO.setup(pinPositive, GPIO.OUT)
GPIO.setup(pinNegative, GPIO.OUT)

GPIO.setup(pinSwitch01, GPIO.IN)
GPIO.setup(pinSwitch02, GPIO.IN)

try:
    while True: 
        if GPIO.input(pinSwitch01) == True: 
            GPIO.output(pinEnable, True)  
            GPIO.output(pinPositive, True)
            GPIO.output(pinNegative, False)

        elif GPIO.input(pinSwitch02) == True: 
            GPIO.output(pinEnable, False)  
            
            
except KeyboardInterrupt: 
    GPIO.cleanup()   
