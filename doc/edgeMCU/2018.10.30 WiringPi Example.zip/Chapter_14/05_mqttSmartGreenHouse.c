#include <stdio.h>
#include <string.h>
#include "./libedge/thingplug.h"
#include "./libedge/temperature.h"
#include "./libedge/dcmotor.h"

void callbackFunction(char * data)
{
	float temp = 0;
	sscanf(data, "%f", &temp);
	printf("callbackFunction: temp=%f\n", temp);
	if(temp>27) rotateDcMotor(0, 1); 
} 

int main()
{
	MQTTClient client;
	char addr[]		= "tcp://mqtt.sktiot.com:1883";
	char id[]			= "edgeilab";
	char pw[]		        = "사용자 인증키";
	char deviceId[]		= "edgeilab_20180101_1";
	char devicePw[] 		= "123456";
	char container[]		= "temperature";

	if(!mqttConnect(&client, addr, id, pw, deviceId)) {
		printf("1. mqtt connect failed\n");
		return FALSE;
	}
	if(!mqttCreateNode(&client, devicePw)) {
		printf("2. mqtt create node failed\n");
		return FALSE;
	}
	if(!mqttCreateRemoteCSE(&client)) {
		printf("3. mqtt create remote cse failed\n");
		return FALSE;
	}
	if(!mqttCreateContainer(&client, container)) {
		printf("4. mqtt create container failed\n");
		return FALSE;
	}
	if(!mqttCreateMgmtCmd(&client)) {
		printf("5. mqtt create mgmt cmd failed\n");
		return FALSE;
	}
	if(!mqttSubscribe(&client, callbackFunction)) {
		printf("6. mqtt subscribe notification failed\n");
		return FALSE;
	}

	int i = 0;
	for(i=0; i<30; i++) {
		float temp = getTempData();
		char strTemp[BUF_SIZE];
		sprintf(strTemp, "%f", temp);
		mqttCreateContentInstance(&client, strTemp);
		sleep(1);
	}

	mqttDisconnect(&client);
	unexportDcMotor();

	return TRUE;
}