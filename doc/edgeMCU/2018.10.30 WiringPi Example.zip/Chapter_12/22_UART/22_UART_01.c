#include <stdio.h>
#include <wiringPi.h>

#define SER_PORT	"/dev/serial0"
#define BAUD_RATE	115200

int main(void)
{
	int dev;

	if((dev = serialOpen(SER_PORT, BAUD_RATE)) < 0)
	{
		return -1;
	}

	printf("Port Open\n");

	serialFlush(dev);

	while(1)
	{
		int ch = serialGetchar(dev);

		if(ch == 'x' || ch == 'X')
		{
			break;
		}

		else
		{
			fputc(ch, stderr);
			serialPutchar(dev, ch);

		}
	}

	printf("Port Closed.\n");
	serialClose(dev);

	return 0;
}
