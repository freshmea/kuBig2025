#include <wiringPi.h>
#include <stdio.h>

const int pinIr = 19;

int main()
{

	wiringPiSetupGpio();

	pinMode(pinIr, INPUT);
	while(1)
	{
		if(!digitalRead(pinIr))
		{
			printf("Read\n");
			delay(100);
		}
	}

	return 0;
}
