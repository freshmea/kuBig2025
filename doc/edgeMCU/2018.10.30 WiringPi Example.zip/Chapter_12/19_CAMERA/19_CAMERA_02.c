#include <stdio.h>
#include <wiringPi.h>
#include <wiringPiI2C.h>

#define SERVO_I2C_ADDR		0x20
#define OUT_PORT0		0x02
#define CONFIG_PORT0		0x06

#define PERIOD 			20000	// 20msec 20,000usec

const int servoUD = 0x01;	// 0000 0001
const int servoLR = 0x02;	// 0000 0010

int fd;

int main(void)
{
	if((fd = wiringPiI2CSetup(SERVO_I2C_ADDR)) < 0)
	{
		return -1;
	}

	wiringPiI2CWriteReg16(fd, CONFIG_PORT0, 0x00);

	while(1) {
		int i;

		// UP, DOWN
		for(i=0; i<50; i++)
		{
			wiringPiI2CWriteReg16(fd, OUT_PORT0, servoUD);
			delayMicroseconds(50);
			wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
			delayMicroseconds(PERIOD-50);
		}


		for(i=0; i<50; i++)
		{
			wiringPiI2CWriteReg16(fd, OUT_PORT0, servoUD);
			delayMicroseconds(600);
			wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
			delayMicroseconds(PERIOD-600);
		}

		for(i=0; i<50; i++)
		{
	                wiringPiI2CWriteReg16(fd, OUT_PORT0, servoUD);
	                delayMicroseconds(1500);
	                wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
	                delayMicroseconds(PERIOD-1500);
		}

                for(i=0; i<50; i++)
                {
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, servoLR);
                        delayMicroseconds(50);
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
                        delayMicroseconds(PERIOD-50);
                }

                for(i=0; i<50; i++)
                {
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, servoLR);
                        delayMicroseconds(1000);
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
                        delayMicroseconds(PERIOD-1000);
                }

                for(i=0; i<50; i++)
                {
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, servoLR);
                        delayMicroseconds(2000);
                        wiringPiI2CWriteReg16(fd, OUT_PORT0, 0x00);
                        delayMicroseconds(PERIOD-2000);
                }

		system("raspistill -t 5000 -o image2.jpg");
	}

	return 0;
}
