#include <stdio.h>
#include <wiringPi.h>

const int pinLed1 = 21;
const int pinLed2 = 20;

int main(void)
{
	wiringPiSetupGpio();

	pinMode(pinLed1, OUTPUT);
	pinMode(pinLed2, OUTPUT);

	while(1)
	{
		digitalWrite(pinLed1, HIGH);
		digitalWrite(pinLed2, LOW);
		delay(1000);
		digitalWrite(pinLed1, LOW);
		digitalWrite(pinLed2, HIGH);
		delay(1000);
	}
	return 0;
}
