#include <stdio.h>
#include <wiringPi.h>

const int pinLed = 21;

int main(void)
{
	wiringPiSetupGpio();

	pinMode(pinLed, OUTPUT);

	while(1)
	{
		digitalWrite(pinLed, HIGH);
		delay(1000);
		digitalWrite(pinLed, LOW);
		delay(1000);
	}
	return 0;
}
