#include <stdio.h>
#include <wiringPi.h>

const int aPinSwitch[2] = {6, 5};
const int aPinLed[2] = {21, 20};

int main(void)
{
	wiringPiSetupGpio();

	int i;
	for(i=0; i<2; i++)
	{
		pinMode(aPinSwitch[i], INPUT);
		pinMode(aPinLed[i], OUTPUT);
	}

	while(1)
	{
		for(i=0; i<2; i++)
		{
			if(digitalRead(aPinSwitch[i]))
			{
				digitalWrite(aPinLed[i], HIGH);
			}
			else
			{
				digitalWrite(aPinLed[i], LOW);
			}
		}
	}
	return 0;
}
