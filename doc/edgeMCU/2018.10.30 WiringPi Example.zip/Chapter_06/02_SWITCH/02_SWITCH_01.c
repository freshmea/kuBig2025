#include <stdio.h>
#include <wiringPi.h>

const int pinSwitch = 6;

int main(void)
{
	wiringPiSetupGpio();

	pinMode(pinSwitch, INPUT);

	while(1)
	{
		if(digitalRead(pinSwitch))
		{
			printf("Pushed\n");
			delay(500);
		}
	}
	return 0;
}
