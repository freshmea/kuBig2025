#include <stdio.h>
#include <wiringPi.h>

const int aPinSwitch[2] = {6, 5};

int main(void)
{
	wiringPiSetupGpio();

	int i;
	for(i=0; i<2; i++)
	{

		pinMode(aPinSwitch[i], INPUT);
	}

	while(1)
	{
		for(i=0; i<2; i++)
		{
			if(digitalRead(aPinSwitch[i]))
			{
				printf("SWITCH[%d] Pushed\n", i);
				delay(500);
			}
		}
	}
	return 0;
}
