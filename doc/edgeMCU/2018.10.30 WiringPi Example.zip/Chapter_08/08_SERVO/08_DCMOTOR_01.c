#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>


const int pinEnable = 12;
const int pinPositive = 4;
const int pinNegative = 25;

int main(void)
{
	wiringPiSetupGpio();

	pinMode(pinPositive, OUTPUT);
	pinMode(pinNegative, OUTPUT);
	softPwmCreate(pinEnable, 0, 200);

	digitalWrite(pinPositive, HIGH);
	digitalWrite(pinNegative, LOW);

	while(1)
	{
		softPwmWrite(pinEnable, 30);
		delay(2000);

		softPwmWrite(pinEnable, 0);
		delay(1000);

		softPwmWrite(pinEnable, 80);
		delay(2000);

		softPwmWrite(pinEnable, 0);
		delay(1000);

	}
	return 0;
}
