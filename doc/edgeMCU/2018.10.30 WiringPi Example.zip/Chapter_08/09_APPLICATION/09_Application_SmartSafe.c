// File : 09_Application_SmartSafe

#include <stdio.h>
#include <wiringPi.h>                 // wiring 라이브러리 참조
#include <softTone.h>                 // Software Tone 라이브러리 참조
#include <softPwm.h>                  // Software PWM 라이브러리 참조
#include <lcd.h>	                 // lcd 라이브러리 참조

const int pinPiezo = 13;		 // Piezo 핀 설정
const int pinServo = 17;		 // Servo Motor 핀 설정
const int pinLed[2] = {21, 20};      // LED 핀 설정
const int pinSwitch[2] = {6, 5};     // Switch 핀 설정

// 음계 초기화
const int aMelody[8] = {131, 147, 165, 175, 196, 220, 247, 262};

int aPassword[6] = {0, 0, 0, 0, 0, 0};     // PW 설정
int input[6] = {0, 0, 0, 0, 0, 1};	        // 입력값 저장 변수

int lcd;                                      // lcd생성
int count = 0;

// 버튼음 설정 함수
void buttonBeep()
{    
	softToneWrite(pinPiezo, aMelody[2]);   // 0.03초간 소리 출력
	delay(30);
	softToneWrite(pinPiezo, 0);
}

// 인터럽트 서비스 루틴 정의
void pushButton0()
{	
	// Switch[0]을 누를 때 발생하는 함수
	input[count] = 0;			       // count번째 입력을 0으로 저장
	lcdPosition(lcd, count, 1);            // lcd 두번 째 줄의 count 번째에
	lcdPuts(lcd, "*");		      // *을 표시
	count++;			              // count 1 증가
	buttonBeep();			      // 버튼음 발생
}

void pushButton1()
{     
	// Switch[1]을 누를 때 발생하는 함수
	input[count] = 1;		         // count번째 입력을 1로 저장
	lcdPosition(lcd, count, 1);      // lcd 두번 째 줄의 count 번째에
	lcdPuts(lcd, "*");		 // *을 표시
	count++;				 // count 1 증가
	buttonBeep();                      // 버튼음 발생
}

int main(void)
{
	wiringPiSetupGpio();               // 핀 번호를 BCM Mode 로 설정
	// 해당 핀을 PWM 핀, 0~100까지 범위 설정
	softPwmCreate(pinServo, 0, 100); 
	softToneCreate(pinPiezo);         // 해당 핀을 Tone 핀으로 설정

	// lcd 초기화
	lcd = lcdInit(2, 16, 4, 16, 26, 18, 27, 22, 23, 0, 0, 0, 0);

	int i;
	for (i = 0; i < 2; i++)
	{
		pinMode(pinSwitch[i], INPUT);  // 스위치 핀을 입력으로 설정
		pinMode(pinLed[i], OUTPUT);    // LED 핀을 출력으로 설정
	}
	lcdClear(lcd);                       // lcd 화면 클리어
	lcdPosition(lcd, 0, 0);             // Cursor를 0,0으로 이동
	// lcd화면에 "press the botton" 출력
	lcdPuts(lcd, "press the botton");  

	// Switch[0]을 누를 경우, RISING Mode, pushButton0함수 호출
	wiringPiISR(pinSwitch[0], INT_EDGE_RISING, pushButton0);

	// Switch[1]을 누를 경우, RISING Mode, pushButton1함수 호출
	wiringPiISR(pinSwitch[1], INT_EDGE_RISING, pushButton1);
	while(1)
	{
		int result;
		if(count == 6)                   // 버튼이 6번 눌린 경우
		{   
			result = 0;                   // 결과 초기화
			for (i = 0; i < 6; i++)
			{  
				// PW와 입력 숫자 비교
				if (aPassword[i] == input[i]) // 숫자가 같을 때마다
					result++;		          // 결과를 1씩 증가
			}
			lcdClear(lcd);			  // lcd 화면 클리어
			lcdPosition(lcd, 0, 0);           // Cursor를 0,0으로 이동

			if(result == 6)                    // 숫자가 6개 맞을 경우
			{  
				lcdPuts(lcd, "unlock!!  ");   // lcd 화면에 "unlock!!" 출력
				softPwmWrite(pinServo, 23);   // Servo -90도 회전
				for (i = 0; i < 2; i++)	  // LED 점등
					digitalWrite(pinLed[i], HIGH);
				for (i = 0; i < 5; i += 2)
				{  
					softToneWrite(pinPiezo, aMelody[i]);   // 소리 출력
					delay(200);
				}
				softToneWrite(pinPiezo, 0);   // 소리 정지
			}
			else                                // 숫자가 틀린 경우
			{    
				lcdPuts(lcd, "lock!!  ");     // lcd 화면에 "lock!!" 출력
				softPwmWrite(pinServo, 5);    // Servo +90도 회전
				for (i = 0; i < 2; i++)
				{   
					digitalWrite(pinLed[i], LOW);          // LED 끔
					softToneWrite(pinPiezo, aMelody[4]);  // 소리 출력
					delay(500);
				}
				softToneWrite(pinPiezo, 0);                 // 소리 정지
			}
			count = 0;                        //count변수에 0 저장
		}
	}
	return 0;
}
