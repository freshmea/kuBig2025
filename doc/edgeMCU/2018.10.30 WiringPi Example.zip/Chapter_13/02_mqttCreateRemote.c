#include <stdio.h>
#include <string.h>
#include "./libedge/thingplug.h"

int main()
{
	MQTTClient client;
	char addr[]	= "tcp://mqtt.sktiot.com:1883";
	char id[]		= "edgeilab";                 // 예시
	char pw[]         	= "사용자 인증키"
	char deviceId[]	= "edgeilab_20180101_1";
	char devicePw[] 	= "123456";

	if(!mqttConnect(&client, addr, id, pw, deviceId)) {
		printf("1. mqtt connect failed\n");
		return FALSE;
	}
	if(!mqttCreateNode(&client, devicePw)) {
		printf("2. mqtt create node failed\n");
		return FALSE;
	}
	if(!mqttCreateRemoteCSE(&client)) {
		printf("3. mqtt create remote cse failed\n");
		return FALSE;
	}
	printf("Create Remote CSE Success\n");
	mqttDisconnect(&client);

	return true;
}
