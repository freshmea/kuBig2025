#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "./libedge/thingplug.h"
#include "./libedge/temperature.h"
#include "./libedge/dcmotor.h"
	
void callbackFunctionTemp(char *data) {
	float temp = 0;
	sscanf(data, "%f", &temp);
	printf("callbackFunction : temp = %f\n", temp);
	if(temp<25) rotateDcMotor(0, 1);
}

int main() {
	MQTTClient client;
	char addr[] = "tcp://mqtt.sktiot.com:1883";
	char id[] = "sjs1210";
	char pw[] = "WEZsQytadnBaOGNWandsMzEvK0ZYVlpMbm5QVXNsYmhGb0ZvU20vbVVGTFlCUEVZNGdFZDdhaHRoTDNTeHpYWA==";
	char deviceId[] = "sjs1210_IoT_EM";
	char devicePw[] = "123456";
	char targetDeviceId[] = "sjs1210_MCU-Node-Relay";
	char containerTemp[] = "temperature";
	char containerHumi[] = "humidity";
	
	if(!mqttConnect(&client, addr, id, pw, deviceId)) {
		printf("1. mqtt connect failed\n");
		return FALSE;
	}
	if(!mqttCreateNode(&client, devicePw)) {
		printf("2. mqtt create node failed\n");
		return FALSE;
	}
	if(!mqttCreateRemoteCSE(&client)) {
		printf("3. mqtt create remote cse failed\n");
		return FALSE;
	} 
	if(!mqttCreateContainer(&client, containerTemp)) {
		printf("4. mqtt create container Temp failed\n");
		return FALSE;
	}
	if(!mqttCreateContainer(&client, containerHumi)) {
		printf("4. mqtt create container Humi failed\n");
		return FALSE;
	}

	if(!mqttCreateMgmtCmd(&client)) {
		printf("5. mqtt create mgmt cmd failed\n");
		return FALSE;
	}
	

	time_t curruntTime;
	curruntTime = time(NULL);
	exportDcMotor();
	while(1) {
		float temp = getTempData();
		float humi = getHumiData();
		char strTemp[BUF_SIZE];
		char strHumi[BUF_SIZE];
		sprintf(strTemp, "%f", temp);
		sprintf(strHumi, "%f", humi);
		
		while(curruntTime + 10 > time(NULL)) {

		}
		mqttCreateContentInstance(&client, containerTemp, strTemp);
		mqttCreateContentInstance(&client, containerHumi, strHumi);
		curruntTime += 10;	
	}
	mqttDisconnect(&client);
	unexportDcMotor();
	
	return TRUE;
}
